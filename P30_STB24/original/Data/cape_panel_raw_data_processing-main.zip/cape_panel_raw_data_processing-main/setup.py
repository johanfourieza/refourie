from setuptools import find_packages, setup

setup(
    name='src', #name of the package is src
    packages=find_packages(),
    version='0.1.0',
    description='This is a project to process the raw transcribed data for the Cape Panel',
    author='jancgreyling',
    license='MIT',
)
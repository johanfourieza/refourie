
# Units of measure unsed

Jan C Greyling

2023-01-30


| Old unit	| Alt. name	| Com.      | Number    | Modern unit   | Source             | 
|----       |----       |----       |----       |----           |--------------------|
| legger	| leaguer    | wine     |	569.23  |	liter       | 152 old gallons or 126 and 7/11ths imperial. From chat GPT - Question: is 152 old gallons equal to 126 and 7/11ths imperial? Answer: 152 gallons is equivalent to around 570.8 imperial gallons, whereas 126 and 7/11ths imperial gallons is equivalent to around 570.2 imperial gallons. So lets take the mean 1 legger = 569.23 liters. |
| mud       | sack	    | depends on the crop | |               | 1 muid (sack) = 4 schepels. 109.1 l, 23.998 (≈24) Imp. gal., 2.99 (≈3) Imp. bushels. Derived from a medieval French word for a dry measure of seeds large enough to plant a set area of land. So the question is how much is a bushel of grain?|
| mud       |sack	    | wheat     | 1.648	    | kg            | [SAGIS grain conversion factors](https://www.sagis.org.za/conversion_table.html) |
| mud       |sack	    | barley	| 65.316	| kg	        | [SAGIS grain conversion factors](https://www.sagis.org.za/conversion_table.html) |
| mud	    |sack	    | rye	    | 81.648	| kg	        | Same as wheat |
| mud	    |sack	    | oats	    | 43.545	| kg	        | [SAGIS grain conversion factors](https://www.sagis.org.za/conversion_table.html) |

# Sources

See "Return of the Produce, Stock, etc. of the Cape of Good Hope, 1896"
![](Units.jpg).
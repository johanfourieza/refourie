# Metadata variable discription

Jan C Greyling

2023-01-30

# Table of contents

- [Introduction](#intro)
- [Census and settler information](#Census-and-settler)
- [Slaves and other persons](#Slaves-and-other-persons)
- [Livestock, produce and products](#products)
- [Assets](#assets)
- [Farm and tenure](#farm)
- [Taxes](#taxes)
- [Born, married and died](#life)
- [Industry](#industry)

# Introduction <a name="intro"></a>

This document provides a concise description of all the variables in the dataset. The metadata order reflects the order of the variables in the dataset, which are ordered by theme and separated as such in this document. Note that the priority of the data cleaning process was to construct the longest consecutive series of each variable. Hence variables that were not exactly the same were merged; see for example, the changes in the ages reported for `settler_sons` over time.

Note that the document is version controlled so that changes can be tracked over time.

# Census and settler information <a name="Census-and-settler"></a>

| Variables	            | notes                 |
|-------                |-----------------------|
| nr                    | Folio number if reported by the tax census - conveys information on the order in which the entries were reported - maybe it can be valuable          |
| year                  | Year of the tax census as indicated by the tab in the the "stellenbosch_panel_raw.xlsx" sheet        |
| add_info              | Additional information if reported        |
| district              | District and field cornet require further cleaning before they can be used. Sometimes they are reported separately or together. For example, in some censuses the field cornet is stated first followed by the district. Both columns were filled down by cencus.        |
| field_cornet          | See above        |
| names_men             | Names of settler men        |
| names_women           | Names of settler women. Note that they are not always reported      |
| settler_men           | Number of settler men. Note that the ages at which persons are regarded as men, women and children differ between censuses. I've combined all types as reported event though the ages differ for continuity's sake this needs to be kept in mind when comparing two years wherein the definition might differ. This was the case for all person types.        |
| settler_women         | Number of settler women. |
| settler_sons          |	Number of settler sons. |
| settler_daughters	    | Number of settler daughters |
| settler_children	    | Number of settler children. Reported in a few censuses, presumably the sum of sons and daughters. |
| servants              | Number of servants. Reported in this form in most censuses. Premsumed to be part of the household, therefore included in this section. |
| servant_coachman      |	The servant sub-categories only reported by a few censuses. |
| servant_personal	    | Number of |
| servant_home	        | Number of |
| servant_cook	        | Number of |

# Slaves and other persons <a name="Slaves-and-other-persons"></a>
| Variables	            | notes   |
|-------                |-----------------------|
| slave_men             |	Number of slave men. Note that the most recent censuses report them as "slaven/apprenticen" or just "slavenapprenticen". I mapped these to slaves. |
| slave_women	        |   Number of |
| slave_sons	        | Number of |
| slave_daughters	    | Number of |
| slave_children	    | Number of |
| khoe_men	            | Mostly reported as Hottentoten but later as coloureds. |
| khoe_women	        | |
| khoe_sons	            | |
| khoe_daughters        | |	
| freeblack_men	        | Number of |
| freeblack_women	    | Number of |
| freeblack_sons	    | Number of |
| freeblack_daughters	| Number of |
| prizenegro_men	    | Number of |
| prizenegro_women	    | Number of |
| prizenegro_sons	    | Number of |
| prizenegro_daughters	| Number of |

# Livestock, produce and products <a name="products"></a>

| Variables	            | notes   |
|-------                |-----------------------|
| cattle	            | Some of the earlier censuses only report "cattle", it is assumed that cattle is the sum of the sub-categories |
| cattle_breeding	    | Number of |
| cattle_work	        | Number of |
| cattle_cows	        | Number of |
| cattle_heifers	    | Number of |
| cattle_calves	        | Number of |
| horses	            | Some of the earlier censuses only report "hoses", it is assumed that cattle is the sum of the sub-categories |
| horse_work	        | Number of |
| horse_breeding	    | Number of |
| horse_pleasure	    | This is reported in a few censuses, bot sure if they are included with "horse_work" if not reported. |
| donkeys	            | Number of |
| sheep	                | Some of the earlier censuses only report "sheep", it is assumed that cattle is the sum of the sub-categories. |
| sheep_breeding	    | Number of |
| sheep_wool	        | Typically reported as Spanish sheep - clearly it represents Merinos from Spain. |
| sheep_wether	        | Number of |
| goats	                | Number of     |
| sheep_goats	        | A few reports this. |
| pigs	                | Number of     |
| sheep_goats_pigs	    | Number of |
| wheat_seed	        | Seed used in mudden|
| wheat_vol	            | Grain produced in mudden|
| barley_seed	        | Seed used in mudden|
| barley_vol	        | Grain produced in mudden|
| rye_seed	            | |
| rye_vol	            | Grain produced in mudden|
| oat_seed	            | |
| oat_vol	            | Grain produced in mudden|
| hay_vol	Pounds      | | 
| maize_vol	Mudden      | Grain produced in mudden|
| potatoes_vol	        | |
| peas_vol	            | Peas produced in mudden
| grains_vol	        | Not sure what this represents, presumably the sum of all |
| barleyryeoat_vol	    | Not sure what this represents, presumably the sum of the three |
| zkoorn	            | No idea what these are. Reported of one or a few more censuses. |
| wheat_bz	            | No idea what these are. Reported of one or a few more censuses. |
| rye_bz                | No idea what these are. Reported of one or a few more censuses. |	
| barleyzk_vol  	    | No idea what these are. Reported of one or a few more censuses. |
| bzkoorn	            | No idea what these are. Reported of one or a few more censuses. |
| bzkoorn1	            | No idea what these are. Reported of one or a few more censuses. |
| vines	                | Number of vines |
| wine                  | Leggers made. Wine becomes brandy, not sure if the wine made also includes those used for brandy making? |
| brandy                | Leggers made |

# Assets <a name="assets"></a>

| Variables	            | notes   |
|-------                |-----------------------|
| words	                | Degens and swords |
| side_arm	            | Some censuses report both side arms and pistols, not sure what they are. |
| pistols	            | |
| rifle	                | |
| wagons                | Allocated to wagons if reported that they had four weels. Probalby used for farming and contract transport. |
| carts	                | Allocated to carts if reported that they had two weels. Probably used for personal transport. |
| wagons_pleasure	    | This is reported by the later censuses, not sure if they were included in "wagons" before the distinction was made. |
| carts_pleasure	    | This is reported by the later censuses, not sure if they were included in "carts" before the distinction was made. |

# Farm and tenure <a name="farm"></a>

These were reported by a few censuses. For most what they mean is unclear.

| Variables	            | notes   |
|-------                |-----------------------|
| farm_name	            | Name of farm or in some cases erf |
| years_owned	        | |
| years_cultivated	    | |
| years_occupied	    | |
| freehold_places	    | |
| freehold_erfs	        | |
| freehold_morgen	    | |
| freehold_srods	    | |
| freehold_sfeet	    | |
| quitrent_places	    | |
| quitrent_morgen	    | |
| quitrent_srods        | |	
| quitrent_sfeet        | |	
| loan_places	        | | 
| area_cultivated	    | |
| area_grazing	        | |
| area_uncultivated	    | |

# Taxes <a name="taxes"></a>

What these respresent and how they were calculated need to be studied. Reported by the most recent censuses in the sample

| Variables	            | notes   |
|-------                |-----------------------|
| cap_tax_pounds	    | |
| cap_tax_shillings	    | |
| cap_tax_dimes	        | |
| servant_tax_pounds	| |
| servant_tax_shillings	| |
| servant_tax_dimes	    | |
| horse_tax_pounds	    | |
| horse_tax_shillings	| |
| horse_tax_dimes	    | |
| stock_tax_pounds	    | |
| stock_tax_shillings	| |
| stock_tax_dimes	    | |
| produce_tax_pounds	| |
| produce_tax_shillings	| |
| produce_tax_dimes	    | |
| wagon_tax_pounds	    | |
| wagon_tax_shillings	| |
| wagon_tax_dimes	    | |
| nonfarm_tax_pounds	| |
| nonfarm_tax_shillings	| |
| nonfarm_tax_dimes	    | |
| income_tax_pounds	    | |
| income_tax_shillings	| |
| income_tax_dimes	    | |
| total _tax_pounds	    | |
| total _tax_shillings	| |
| total _tax_dimes	    | |
| nonfarm_income        | |

# Born, married and died <a name="life"></a>

| Variables	            | notes   |
|-------                |-----------------------|
| persons_born	        | Number of during the year, the period was not always clear but censuses indicate that it was counted between 1 July and 30 June|
| persons_married	    | Number of |
| persons_died	        | Number of |
| settlers_born	        | Number of |
| settler_died	        | Number of |
| slaves_born	        | Number of |
| slaves_died	        | Number of |
| khoe_born	            | Number of |
| khoi_died	            | Number of |
| freeblacks_born	    | Number of
| freeblacks_died	    | Number of
| prizenegro_born	    | Number of
| prizenegro_died	    | Number of
| workers_farm	        | Number of
| workers_retail	    | Number of
| workers_factory	    | Number of |

# Industry <a name="industry"></a>

Reported by some of the most recent censuses

| Variables	            | notes   |
|-------                |-----------------------|
mills_water	            | |
mills_horse	            | |
tanneries	            | |

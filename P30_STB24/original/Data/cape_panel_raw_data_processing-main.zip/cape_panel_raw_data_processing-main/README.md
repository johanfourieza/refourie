Cape Panel Raw Data Processing
==============================

The objective of this project is to process the raw transcribed data for the Cape Panel Project. This codebase automates the cleaning of Stellenbosch data with minimal Excel-based intervention. However, some changes had to be made in Excel if variable names were not unique and a difference could not be corrected programmatically. Note that such changes were made to  `data\interim\stellenbosch_panel_raw_unmerged.xlsx`.

Sheets with merged cells posed a substantial challenge,  this was overcome using the `openpyxl` package, whereby the Excel sheets themselves could be edited before they were imported into python using `pandas`. The script `src/data/1_merged_cell_remove.py` opens the Excel workbook, unmerges all merged cells and fills the value that the merged cell had to all the unmerged cells; after that, one can run the notebooks in sequence. 

Note the project organisation below:

Project Organization
------------

    ├── LICENSE
    ├── Makefile            <- Makefile with commands like `make data` or `make train`
    ├── README.md           <- The top-level README for developers using this project.
    ├── data
    │   ├── external        <- Data from third party sources.
    |   ├── processed       <- The final, canonical data sets for modeling.
    │   ├── interim         <- Intermediate data that has been transformed.
    │        ├── stellenbosch_panel_raw_unmerged.xlsx - the unmerged and corrected raw data
    │        ├── stellenbosch_panel_raw.pickle          <- the imported sheets as a pickle dictionary
    │        ├── col_names_stellenbosch.csv             <- a printout of all of the raw variable names, used for standardisation with "col_names_stellenbosch.csv"
    │        ├── col_names_stellenbosch.xlsx            <- the standardised column names used in the lookup and replace function
    │        ├── stellenbosch_panel_raw.pickle          <- the imported sheets saved as a pickle dictionary
    │        ├── stellenbosch_std_var_names.pickle      <- the imported sheets with standardised variable names saved as a pickle dictionary
    │        └── var_names_ordered.csv                  <- all of the variable names manually ordered so that they are grouped logically in the dataset.
    │   └── raw             <- The original, immutable data dump.
    │        └── stellenbosch_panel_raw.xlsx
    │
    ├── docs                <- A default Sphinx project; see sphinx-doc.org for details
    │
    ├── models              <- Trained and serialized models, model predictions, or model summaries
    │
    ├── notebooks           <- Jupyter notebooks
    │   ├── 1_Stellenbosch_data_import.ipynb                    <- Import all of the sheets as dictionary of sheets and save as pickle file
    │   ├── 2_Stellenbosch_data_column_standardisation.ipynb    <- Genereate the column names and standardise them.
    │   └── 3_Stellenbosch_data_merge_clean.ipynb               <- Merge the individual dataframes into a single df and clean
    │
    ├── references          <- Data dictionaries, manuals, and all other explanatory materials.
    │   |── Metadata.md     <- Description of all the dataset variables.
    │   └── Units.md        <- Description of units used in the dataset.
    │
    ├── reports             <- Generated analysis as HTML, PDF, LaTeX, etc.
    │   └── figures         <- Generated graphics and figures to be used in reporting
    │
    ├── requirements.txt    <- The requirements file for reproducing the analysis environment 
                               i.e. the packages needed for the analysis
    │
    ├── setup.py            <- makes project pip installable (pip install -e .) so src can be imported
    ├── src                 <- Source code for use in this project.
    │   ├── __init__.py     <- Makes src a Python module
    │   │
    │   ├── data            <- Scripts to download or generate data
    │   │   └── 1_merged_cell_remove.py  <- The script to unmerge all cells in "stellenbosch_panel_raw.xlsx", 
                                            the output is "stellenbosch_panel_raw_unmerged.xlsx"
    │   │
    │   ├── features        <- Scripts to turn raw data into features for modeling
    │   ├── models          <- Scripts to train models and then use trained models to make
    │   └── visualization   <- Scripts to create exploratory and results-oriented visualizations
    │
    └── tox.ini             <- tox file with settings for running tox; see tox.readthedocs.io


--------

<p><small>Project based on the <a target="_blank" href="https://drivendata.github.io/cookiecutter-data-science/">cookiecutter data science project template</a>. #cookiecutterdatascience</small></p>


#packages
import pandas as pd
from openpyxl.utils import range_boundaries
from openpyxl import load_workbook

############################################################################################################

from src import project_dir
print(project_dir)

#file path for dataset
raw_data = project_dir/"data/raw/stellenbosch_panel_raw.xlsx"

############################################################################################################

#make a list of sheet names
xlsx = pd.ExcelFile(raw_data)
sheet_names = xlsx.sheet_names
print(sheet_names)

#iterate through list and select values between 1685 and 1710
selected_sheets = [value for value in sheet_names if value.isdigit() and int(value) >= 1685 and int(value) <= 1844]

############################################################################################################

wb = load_workbook(raw_data)

#loop through each sheet in the workbook
for sheet_name in selected_sheets:

    sheet = wb[sheet_name]

    merge_list = []
    for merge in sheet.merged_cells.ranges:
        merge_list.append(merge)

    for group in merge_list:
        print("Changing merged cells " + str(group.coord))
        min_col, min_row, max_col, max_row = range_boundaries(group.coord)
        top_left_cell_value = sheet.cell(row=min_row, column=min_col).value
        sheet.unmerge_cells(str(group))
        for row in sheet.iter_rows(min_col=min_col, min_row=min_row, max_col=max_col, max_row=max_row):
            for cell in row:
                cell.value = top_left_cell_value

wb.save(project_dir/"data/interim/stellenbosch_panel_raw_unmerged.xlsx")

wb.close()